# __init__.py
__all__ = [  'dom3ds', 'basicmodel', 'loadmodel', 'loadtexture', 'GL' ]
version = (0,4)
