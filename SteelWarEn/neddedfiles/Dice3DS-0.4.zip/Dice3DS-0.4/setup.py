# setup.py

long_description = """Read, write, and manipulate 3DS files.

Dice3DS is a package to to read, write, and manipulate 3D Studio
format files in Python.  Also includes code to convert 3DS files into
an OpenGL display list.

"""

from distutils.core import setup

dist = setup(name = "Dice3DS",
	     version = "0.4",
	     description = "Read, write, and manipulate 3DS files.",
	     long_description = long_description,
	     author = "Carl Banks",
	     author_email = "dice3ds-1@aerojockey.com",
	     url = "http://www.aerojockey.com/software/dice3ds",
	     license = "BSD Style",
	     platforms = "Unix. Other platforms might work. Little endian.",
	     packages = [ 'Dice3DS', 'Dice3DS.example' ],
	     scripts = [ 'dump3ds', 'view3ds' ])

